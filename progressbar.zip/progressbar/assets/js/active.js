/* ---------------------------------------------
 common scripts
 --------------------------------------------- */
(function($) {
    'use strict'; // use strict to start

    jQuery(document).ready(function($) {
	     
        //single progress bar
        
         $('#cirlc-1').circleProgress({
            value: 1,
            size: 250,
            thickness:2,
            fill: '#FFA100',

          }).on('circle-animation-progress', function(event, progress) {
                $(this).find('.circle-inner').html(Math.round(100 * progress) + '<i>%</i>');
          });

        //single progress bar
        
         $('#cirlc-2').circleProgress({
            value: 0,
            size: 250,            
            thickness:2,
            fill: '#FFA100',

          }).on('circle-animation-progress', function(event, progress) {
                $(this).find('.circle-inner').html(Math.round(0 * progress) + '<i>%</i>');
          });

        //single progress bar
        
         $('#cirlc-3').circleProgress({
            value: 0.9,
            size: 250,           
                        
            thickness:2,
            fill: '#FFA100',
            emptyFill: '#fff',
            
          }).on('circle-animation-progress', function(event, progress) {
                $(this).find('.circle-inner').html(Math.round(90 * progress) + '<i>%</i>');
          });

        //single progress bar

         $('#cirlc-4').circleProgress({
            value: 0.7,
            size: 250,
                        
            thickness:2,
            fill: '#FFA100',
            emptyFill: '#fff',
          }).on('circle-animation-progress', function(event, progress) {
                $(this).find('.circle-inner').html(Math.round(70 * progress) + '<i>%</i>');
          });


        
    });

	

    jQuery(window).load(function() {
		

    });




}(jQuery));